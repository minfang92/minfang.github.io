

import numpy as np
import quantecon as qe
import utils
import random
import time


class Maturity_Economy_Simulation:

    def __init__(self,
                 rbar = 0.01,
                 rho_r = 0.5,  # persistence in interest rate
                 eta_r = 0.08,  # st dev of interest rate
                 rho_z = 0.86,  # persistence in productivity
                 eta_z = 0.03,  # st dev of productivity
                 nz = 11,  # number of points in z grid
                 nr = 11,
                 theta_k = 1,
                 theta_bs = 0,
                 theta_bl = 0,
                 phi = 0,
                 beta = 0,
                 delta = 0.025,
                 alpha = 0.34,
                 epsilon = 0.005):

        # Save parameters
        self.rbar, self.rho_r, self.eta_r = rbar, rho_r, eta_r
        self.rho_z, self.eta_z, = rho_z, eta_z
        self.nz, self.nr = nz, nr
        self.theta_k, self.theta_bs, self.theta_bl, self.phi, self.beta = theta_k, theta_bs, theta_bl, phi, beta
        self.delta, self.alpha, self.epsilon = delta, alpha, epsilon

        name =  "beta" + str(beta) + "thetak" + str(theta_k) + "_" + "thetabs" + str(theta_bs) + "_" + "thetabl" + str(theta_bl) + "_" + "phi" + str(phi)+ "_" + "epsilon" + str(epsilon)+ "_" + "eta_z" + str(eta_z)

        # load decision rules
        self.Vd = utils.check_load_data('Vd'+name)
        self.Vd = np.asarray(self.Vd)

        self.Vc = utils.check_load_data('Vc'+name)
        self.Vc = np.asarray(self.Vc)

        self.qs = utils.check_load_data('qs'+name)
        self.qs = np.asarray(self.qs)

        self.ql = utils.check_load_data('ql'+name)
        self.ql = np.asarray(self.ql)

        self.next_B_index = utils.check_load_data('nextB'+name)
        self.next_B_index = np.asarray(self.next_B_index)

        self.next_f_index = utils.check_load_data('nextf'+name)
        self.next_f_index = np.asarray(self.next_f_index)

        self.next_k_index = utils.check_load_data('nextk'+name)
        self.next_k_index = np.asarray(self.next_k_index)

        self.Bgrid = utils.check_load_data('Bgrid'+name)
        self.Bgrid = np.asarray(self.Bgrid)

        self.fgrid = utils.check_load_data('fgrid'+name)
        self.fgrid = np.asarray(self.fgrid)

        self.kgrid = utils.check_load_data('kgrid'+name)
        self.kgrid = np.asarray(self.kgrid)

        self.zgrid = utils.check_load_data('zgrid'+name)
        self.zgrid = np.asarray(self.zgrid)

        self.rgrid = utils.check_load_data('rgrid'+name)
        self.rgrid = np.asarray(self.rgrid)

        # simulate: for statistics

        T = 210
        TIMES = 3000

        r_init = np.searchsorted(self.rgrid, self.rgrid.mean())
        mc_r = qe.markov.tauchen(rho_r,eta_r, m=3, n=self.nr)
        r_common_indices = mc_r.simulate_indices(T, init=r_init)

        z_vec = np.zeros((TIMES, T))
        k_vec = np.zeros((TIMES, T))
        B_vec = np.zeros((TIMES, T))
        f_vec = np.zeros((TIMES, T))
        qs_vec = np.zeros((TIMES, T))
        ql_vec = np.zeros((TIMES, T))
        invest_vec = np.zeros((TIMES, T))
        y_vec = np.zeros((TIMES, T))
        default_vec = np.zeros((TIMES, T))
        z = np.zeros((TIMES, T - 100))
        k = np.zeros((TIMES, T - 100))
        B = np.zeros((TIMES, T - 100))
        f = np.zeros((TIMES, T - 100))
        qs = np.zeros((TIMES, T - 100))
        ql = np.zeros((TIMES, T - 100))
        invest = np.zeros((TIMES, T - 100))
        y = np.zeros((TIMES, T - 100))
        default = np.zeros((TIMES, T - 100))

        np.random.seed(42)
        for i in range(TIMES):
            (z_vec[i], k_vec[i], B_vec[i], f_vec[i], qs_vec[i], ql_vec[i], invest_vec[i], y_vec[i],
             default_vec[i]) = self.simulate(r_common_indices, T)
            z_temp = z_vec[i]
            z_temp = z_temp[100:T]
            z[i] = z_temp
            k_temp = k_vec[i]
            k_temp = k_temp[100:T]
            k[i] = k_temp
            B_temp = B_vec[i]
            B_temp = B_temp[100:T]
            B[i] = B_temp
            f_temp = f_vec[i]
            f_temp = f_temp[100:T]
            f[i] = f_temp
            qs_temp = qs_vec[i]
            qs_temp = qs_temp[100:T]
            qs[i] = qs_temp
            ql_temp = ql_vec[i]
            ql_temp = ql_temp[100:T]
            ql[i] = ql_temp
            invest_temp = invest_vec[i]
            invest_temp = invest_temp[100:T]
            invest[i] = invest_temp
            y_temp = y_vec[i]
            y_temp = y_temp[100:T]
            y[i] = y_temp
            default_temp = default_vec[i]
            default_temp = default_temp[100:T]
            default[i] = default_temp

        # make sure range is not too small or too large
        print("-------make sure of range-------")
        print("Bmin")
        print(np.min(B))
        print("Bmax")
        print(np.max(B))

        print("kmin")
        print(np.min(k))
        print("kmax")
        print(np.max(k))

        print("-------all(not conditional)-------")

        print("mean of leverage")
        print(np.mean(B / k))
        print("median of leverage")
        print(np.median(B / k))

        print("mean of maturity")
        print(np.mean(f))
        print("median of maturity")
        print(np.median(f))

        print("mean of investment rate")
        print(np.mean(invest / k))
        print("mean of sales(output)")
        print(np.mean(y))
        print("default probability")
        print(np.mean(default))


        # Calculate statistics for simulations that does not default
        z_nodef_mean = []
        k_nodef_mean = []
        def_nodef_mean = []
        B_nodef_mean = []
        f_nodef_mean = []
        invest_rate_nodef_mean = []
        invest_rate_nodef_vol = []
        y_nodef_mean = []
        y_nodef_vol = []

        for i in range(TIMES):
            z_nodef = []
            k_nodef = []
            def_nodef = []
            B_nodef = []
            f_nodef = []
            invest_rate_nodef = []
            y_nodef = []
            for t in range(T - 100):
                if default[i].mean() == 0:
                    z_nodef.append(z[i, t])
                    k_nodef.append(k[i, t])
                    B_nodef.append(B[i, t])
                    f_nodef.append([f[i, t]])
                    y_nodef.append(y[i, t])
                    def_nodef.append(default[i, t])
                    invest_rate_nodef.append(invest[i, t] / k[i, t])

            if len(z_nodef) > 0:
                z_nodef_mean.append(np.mean(z_nodef))
                k_nodef_mean.append(np.mean(k_nodef))
                B_nodef_mean.append(np.mean(B_nodef))
                f_nodef_mean.append(np.mean(f_nodef))
                def_nodef_mean.append(np.mean(def_nodef))
                invest_rate_nodef_mean.append(np.mean(invest_rate_nodef))
                invest_rate_nodef_vol.append(np.std(invest_rate_nodef))
                y_nodef_mean.append(np.mean(y_nodef))
                y_nodef_vol.append(np.std(y_nodef))

        z_nodef_mean = np.array(z_nodef_mean)
        k_nodef_mean = np.array(k_nodef_mean)
        B_nodef_mean = np.array(B_nodef_mean)
        f_nodef_mean = np.array(f_nodef_mean)
        def_nodef_mean = np.array(def_nodef_mean)
        invest_rate_nodef_mean = np.array(invest_rate_nodef_mean)
        invest_rate_nodef_vol = np.array(invest_rate_nodef_vol)
        y_nodef_mean = np.array(y_nodef_mean)
        y_nodef_vol = np.array(y_nodef_vol)

        print("------conditional on no default------")
        print("mean of leverage")
        print(np.mean(B_nodef_mean/ k_nodef_mean))

        print("median of leverage")
        print(np.median(B_nodef_mean  / k_nodef_mean))

        print("mean of maturity")
        print(np.mean(f_nodef_mean))

        print("median of maturity")
        print(np.median(f_nodef_mean))

        print("mean of investment rate")
        print(np.mean(invest_rate_nodef_mean))

        print("volatility of investment rate")
        print(np.mean(invest_rate_nodef_vol))

        # Write to a file

        filename = name + '.txt'
        file = open(filename, 'a')
        file.write(" " + "\n")

        # investment rate mean
        file.write(str(invest_rate_nodef_mean.mean() * 100) + "\n")
        d1 = abs(invest_rate_nodef_mean.mean() * 100 - 5.8) / 5.8

        # default rate
        file.write(str(default.mean() * 100) + "\n")
        d2 = abs(default.mean() * 100 - 0.75) / 0.75

        # leverage mean
        file.write(str((B_nodef_mean  / k_nodef_mean).mean() * 100) + "\n")
        d3 = abs((B_nodef_mean / k_nodef_mean).mean() * 100 - 35.2) / 35.2

        # maturity mean
        file.write(str(f.mean() * 100) + "\n")
        d4 = abs(f.mean() * 100 - 84.2) / 84.2

        temp1 = [d1, d2, d3, d4]
        dist1 = max(temp1)

        temp2 = [d1, d2, d3, d4]
        dist2 = sum(temp2)


        file.write(" " + "\n")
        file.write(" " + "\n")

        file.write(str(dist1) + "\n")
        file.write(str(dist2) + "\n")

        file.write(str(np.max(B)) + "\n")
        file.write(str(np.max(k)) + "\n")

        file.close()

        print('Done.')

    def simulate(self, r_common_indices, T, z_init=None, k_init=None, B_init=None, f_init=None):

        zero_B_index = np.searchsorted(self.Bgrid, 0)

        if z_init is None:
            z_init = np.searchsorted(self.zgrid, self.zgrid.mean())
        if k_init is None:
            k_init = np.searchsorted(self.kgrid, self.kgrid.mean())
        if B_init is None:
            B_init = zero_B_index
        if f_init is None:
            f_init = np.searchsorted(self.fgrid, self.fgrid.mean())

        mc_z = qe.markov.tauchen(self.rho_z, self.eta_z, m=3, n=self.nz)
        z_sim_indices = mc_z.simulate_indices(T, init=z_init)
        k_sim_indices = np.zeros(T, dtype=np.int32)
        k_sim_indices[0] = k_init
        B_sim_indices = np.zeros(T, dtype=np.int32)
        B_sim_indices[0] = B_init
        f_sim_indices = np.zeros(T, dtype=np.int32)
        f_sim_indices[0] = f_init
        qs_sim = np.ones(T)
        ql_sim = np.ones(T)
        invest = np.ones(T)
        y_sim = np.ones(T)
        in_default_series = np.zeros(T, dtype=np.int32)

        for t in range(T - 1):
            zi, ki, ri, Bi, fi = z_sim_indices[t], k_sim_indices[t], r_common_indices[t], B_sim_indices[t], f_sim_indices[t]
            if self.Vc[zi, ki, ri, Bi, fi] < self.Vd[zi, ki, ri]:
                in_default_series[t] = 1
                Bi_next = zero_B_index
                fi_next = 0
                ki_next = 0
            else:
                in_default_series[t] = 0
                newB_index = self.next_B_index[zi, ki, ri, Bi, fi]
                Bi_next = newB_index
                newf_index = self.next_f_index[zi, ki, ri, Bi, fi]
                fi_next = newf_index
                ki_next = self.next_k_index[zi, ki, ri, Bi, fi]
                if random.uniform(0, 1) < self.epsilon:
                    Bi_next = zero_B_index
                    fi_next = 0
                    ki_next = 0

            B_sim_indices[t + 1] = Bi_next
            f_sim_indices[t + 1] = fi_next
            k_sim_indices[t + 1] = ki_next
            invest[t] = self.kgrid[ki_next] - (1-self.delta)*self.kgrid[ki] + self.theta_k / 2 * (self.kgrid[ki_next] / self.kgrid[ki] - 1 ) ** 2 * self.kgrid[ki]
            qs_sim[t] = self.qs[zi, ki_next, ri, Bi_next, fi_next]
            ql_sim[t] = self.ql[zi, ki_next, ri, Bi_next, fi_next]
            y_sim[t] = self.zgrid[zi] * (self.kgrid[ki] ** self.alpha)

        B_sim_indices[-1] = B_sim_indices[-2]
        f_sim_indices[-1] = f_sim_indices[-2]
        k_sim_indices[-1] = k_sim_indices[-2]
        qs_sim[-1] = qs_sim[-2]
        ql_sim[-1] = ql_sim[-2]
        invest[-1] = invest[-2]
        y_sim[-1] = y_sim[-2]

        return_vecs = (self.zgrid[z_sim_indices],
                       self.kgrid[k_sim_indices],
                       self.Bgrid[B_sim_indices],
                       self.fgrid[f_sim_indices],
                       qs_sim,
                       ql_sim,
                       invest,
                       y_sim,
                       in_default_series)
        return return_vecs


if __name__ == "__main__":
    me = Maturity_Economy_Simulation()
    print('Done')
