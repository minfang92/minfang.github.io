
import numpy as np
import quantecon as qe
import random
import utils


class Simulation:

    def __init__(self,
                 rbar = 0.01,
                 rho_r = 0.5,  # persistence in interest rate
                 eta_r = 0.08,  # st dev of interest rate
                 rho_z = 0.9,  # persistence in productivity
                 eta_z = 0.03,  # st dev of productivity
                 nz = 200,  # number of points in z grid
                 nr = 11,
                 theta_k = 0.5,
                 theta_bs = 0.12,
                 theta_bl = 1.17,
                 phi = 1.605,
                 beta = 0.96,
                 delta = 0.025,
                 alpha = 0.65,
                 epsilon = 0.01):

        self.rbar, self.rho_r, self.eta_r = rbar, rho_r, eta_r
        self.rho_z, self.eta_z, = rho_z, eta_z
        self.nz, self.nr = nz, nr
        self.theta_k, self.theta_bs, self.theta_bl, self.phi, self.beta = theta_k, theta_bs, theta_bl, phi, beta
        self.delta, self.alpha, self.epsilon = delta, alpha, epsilon

        # load decision rules
        self.next_B_index = utils.check_load_data('nextB')
        self.next_B_index = np.asarray(self.next_B_index)

        self.next_k_index = utils.check_load_data('nextk')
        self.next_k_index = np.asarray(self.next_k_index)

        self.next_f_index = utils.check_load_data('nextf')
        self.next_f_index = np.asarray(self.next_f_index)

        self.Vd = utils.check_load_data('Vd')
        self.Vd = np.asarray(self.Vd)

        self.Vc = utils.check_load_data('Vc')
        self.Vc = np.asarray(self.Vc)

        self.qs = utils.check_load_data('qs')
        self.qs = np.asarray(self.qs)

        self.ql = utils.check_load_data('ql')
        self.ql = np.asarray(self.ql)
        
        self.zgrid = utils.check_load_data('zgrid')
        self.zgrid = np.asarray(self.zgrid)

        self.Bgrid = utils.check_load_data('Bgrid')
        self.Bgrid = np.asarray(self.Bgrid)

        self.fgrid = utils.check_load_data('fgrid')
        self.fgrid = np.asarray(self.fgrid)

        self.kgrid = utils.check_load_data('kgrid')
        self.kgrid = np.asarray(self.kgrid)

        self.rgrid = utils.check_load_data('rgrid')
        self.rgrid = np.asarray(self.rgrid)

    
        # interpolate for new decision rules, increase grid points for z
        mc_z = qe.markov.tauchen(rho_z, eta_z, m=3, n=nz)
        zgrid_new = np.exp(mc_z.state_values)

        nB = len(self.Bgrid)
        nk = len(self.kgrid)
        nf = len(self.fgrid)

        Vc_new = np.zeros((nz,nk,nr, nB, nf))
        Vd_new = np.zeros((nz,nk,nr))
        qs_new = np.zeros((nz, nk, nr, nB, nf))
        ql_new = np.zeros((nz, nk, nr, nB, nf))

        next_k_index_new = np.zeros((nz,nk,nr, nB, nf), dtype=np.int32)
        next_B_index_new = np.zeros((nz, nk, nr, nB, nf), dtype=np.int32)
        next_f_index_new = np.zeros((nz, nk, nr, nB, nf), dtype=np.int32)

        for ik in range(nk):
            for ir in range(nr):
                Vd_new[:, ik, ir] = np.interp(zgrid_new, self.zgrid, self.Vd[:, ik, ir])
                for iB in range(nB):
                    for i_f in range(nf):
                        Vc_new[:, ik, ir, iB, i_f] = np.interp(zgrid_new, self.zgrid, self.Vc[:, ik, ir, iB, i_f])
                        qs_new[:, ik, ir, iB, i_f] = np.interp(zgrid_new, self.zgrid, self.qs[:, ik, ir, iB, i_f])
                        ql_new[:, ik, ir, iB, i_f] = np.interp(zgrid_new, self.zgrid, self.ql[:, ik, ir, iB, i_f])
                        next_k_value = np.interp(zgrid_new, self.zgrid, self.kgrid[self.next_k_index[:, ik, ir, iB, i_f]])
                        next_k_index = np.searchsorted(self.kgrid, next_k_value)
                        next_k_index_new[:, ik, ir, iB, i_f] = next_k_index

                        next_B_value = np.interp(zgrid_new, self.zgrid, self.Bgrid[self.next_B_index[:, ik, ir, iB, i_f]])
                        next_B_index = np.searchsorted(self.Bgrid, next_B_value)
                        next_B_index_new[:, ik, ir, iB, i_f] = next_B_index

                        next_f_value = np.interp(zgrid_new, self.zgrid, self.fgrid[self.next_f_index[:, ik, ir, iB, i_f]])
                        next_f_index = np.searchsorted(self.fgrid, next_f_value)
                        next_f_index_new[:, ik, ir, iB, i_f] = next_f_index

        # interpolate for new decision rules, increase grid points for k
        nk_new = 200
        kgrid_new = np.linspace(0.5, 4.5, nk_new)
        next_k_index_new2 = np.zeros((nz,nk_new,nr, nB, nf), dtype=np.int32)
        next_B_index_new2 = np.zeros((nz, nk_new, nr, nB, nf), dtype=np.int32)
        next_f_index_new2 = np.zeros((nz, nk_new, nr, nB, nf), dtype=np.int32)
        Vc_new2 = np.zeros((nz,nk_new,nr, nB, nf))
        Vd_new2 = np.zeros((nz,nk_new,nr))
        qs_new2 = np.zeros((nz, nk_new, nr, nB, nf))
        ql_new2 = np.zeros((nz, nk_new, nr, nB, nf))

        for iz in range(nz):
            for ir in range(nr):
                Vd_new2[iz, :, ir] = np.interp(kgrid_new, self.kgrid, Vd_new[iz, :, ir])
                for iB in range(nB):
                    for i_f in range(nf):
                        next_k_value = np.interp(kgrid_new, self.kgrid,
                                                  self.kgrid[next_k_index_new[iz, :, ir, iB, i_f]])
                        next_k_index = np.searchsorted(kgrid_new, next_k_value)
                        next_k_index_new2[iz, :, ir, iB, i_f] = next_k_index

                        next_B_value = np.interp(kgrid_new, self.kgrid,
                                                self.Bgrid[next_B_index_new[iz, :, ir, iB, i_f]])
                        next_B_index = np.searchsorted(self.Bgrid, next_B_value)
                        next_B_index_new2[iz, :, ir, iB, i_f] = next_B_index

                        next_f_value = np.interp(kgrid_new, self.kgrid,
                                                self.fgrid[next_f_index_new[iz, :, ir, iB, i_f]])
                        next_f_index = np.searchsorted(self.fgrid, next_f_value)
                        next_f_index_new2[iz, :, ir, iB, i_f] = next_f_index
                        Vc_new2[iz, :, ir, iB, i_f] = np.interp(kgrid_new, self.kgrid, Vc_new[iz, :, ir, iB, i_f])
                        qs_new2[iz, :, ir, iB, i_f] = np.interp(kgrid_new, self.kgrid, qs_new[iz, :, ir, iB, i_f])
                        ql_new2[iz, :, ir, iB, i_f] = np.interp(kgrid_new, self.kgrid, ql_new[iz, :, ir, iB, i_f])

        self.zgrid = zgrid_new
        self.kgrid = kgrid_new
        self.Vd = Vd_new2
        self.Vc = Vc_new2
        self.qs = qs_new2
        self.ql = ql_new2

        self.next_k_index = next_k_index_new2
        self.next_B_index = next_B_index_new2
        self.next_f_index = next_f_index_new2

        # Simulate to generate moments
        T = 500
        TIMES = 30000

        r_vec = np.zeros((TIMES, T))
        np.random.seed(42)
        for i in range(TIMES):
            r_init = np.searchsorted(self.rgrid, self.rgrid.mean())
            mc_r = qe.markov.tauchen(rho_r,eta_r, m=3, n=self.nr)
            r_common_indices = mc_r.simulate_indices(T, init=r_init)
            r_init_val = self.rgrid[r_common_indices[T-101]]
            r_init_val = r_init_val * 0.825
            r_init = np.searchsorted(self.rgrid, r_init_val)
            r_common_indices[T-100:T] = mc_r.simulate_indices(T-(T-100), init=r_init)
            r_vec[i] = self.rgrid[r_common_indices]
        r_common = np.mean(r_vec, axis = 0)
        r_common_indices = np.searchsorted(self.rgrid, r_common)

        z_vec = np.zeros((TIMES, T))
        k_vec = np.zeros((TIMES, T))
        B_vec = np.zeros((TIMES, T))
        f_vec = np.zeros((TIMES, T))
        qs_vec = np.zeros((TIMES, T))
        ql_vec = np.zeros((TIMES, T))
        invest_vec = np.zeros((TIMES, T))
        y_vec = np.zeros((TIMES, T))
        default_vec = np.zeros((TIMES, T))
        z = np.zeros((TIMES, T - 100))
        k = np.zeros((TIMES, T - 100))
        B = np.zeros((TIMES, T - 100))
        f = np.zeros((TIMES, T - 100))
        qs = np.zeros((TIMES, T - 100))
        ql = np.zeros((TIMES, T - 100))
        invest = np.zeros((TIMES, T - 100))
        y = np.zeros((TIMES, T - 100))
        default = np.zeros((TIMES, T - 100))

        np.random.seed(42)
        for i in range(TIMES):
            (z_vec[i], k_vec[i], B_vec[i], f_vec[i], qs_vec[i], ql_vec[i], invest_vec[i], y_vec[i],
             default_vec[i]) = self.simulate_shockr(r_common_indices, T)
            
            z_temp = z_vec[i]
            z_temp = z_temp[100:T]
            z[i] = z_temp
            k_temp = k_vec[i]
            k_temp = k_temp[100:T]
            k[i] = k_temp
            B_temp = B_vec[i]
            B_temp = B_temp[100:T]
            B[i] = B_temp
            f_temp = f_vec[i]
            f_temp = f_temp[100:T]
            f[i] = f_temp
            qs_temp = qs_vec[i]
            qs_temp = qs_temp[100:T]
            qs[i] = qs_temp
            ql_temp = ql_vec[i]
            ql_temp = ql_temp[100:T]
            ql[i] = ql_temp
            invest_temp = invest_vec[i]
            invest_temp = invest_temp[100:T]
            invest[i] = invest_temp
            y_temp = y_vec[i]
            y_temp = y_temp[100:T]
            y[i] = y_temp
            default_temp = default_vec[i]
            default_temp = default_temp[100:T]
            default[i] = default_temp

        r_common_indices = r_common_indices[100:T]
        r_common = r_common[100:T]

        # save and plot
        # all firms
        z_nodef = []
        k_nodef = []
        B_nodef = []
        f_nodef = []
        qs_nodef = []
        ql_nodef = []
        invest_nodef = []
        y_nodef = []
        default_nodef = []

        for i in range(TIMES):
            z_nodef.append(z[i])
            k_nodef.append(k[i])
            B_nodef.append(B[i])
            f_nodef.append(f[i])
            qs_nodef.append(qs[i])
            ql_nodef.append(ql[i])
            invest_nodef.append(invest[i])
            y_nodef.append(y[i])
            default_nodef.append(default[i])
        z_nodef = np.array(z_nodef)
        k_nodef = np.array(k_nodef)
        B_nodef = np.array(B_nodef)
        f_nodef = np.array(f_nodef)
        qs_nodef = np.array(qs_nodef)
        ql_nodef = np.array(ql_nodef)
        invest_nodef = np.array(invest_nodef)
        y_nodef = np.array(y_nodef)
        default_nodef = np.array(default_nodef)
        z = np.mean(z_nodef, axis=0)
        k = np.mean(k_nodef, axis=0)
        B = np.mean(B_nodef, axis=0)
        f = np.mean(f_nodef, axis=0)
        qs = np.mean(qs_nodef, axis=0)
        ql = np.mean(ql_nodef, axis=0)
        invest = np.mean(invest_nodef, axis=0)
        y = np.mean(y_nodef, axis=0)
        default = np.mean(default_nodef, axis=0)

        # change to percentage change
        T = 400
        z_p = np.ones(T)
        k_p = np.ones(T)
        B_p = np.ones(T)
        invest_p = np.ones(T)
        y_p = np.ones(T)

        for t in range(T):
            z_p[t] = (np.log(z[t]) - np.log(z[T - 101])) * 100
            k_p[t] = (np.log(k[t]) - np.log(k[T - 101])) * 100
            B_p[t] = (np.log(B[t]) - np.log(B[T - 101])) * 100
            invest_p[t] = (np.log(invest[t]) - np.log(invest[T - 101])) * 100
            y_p[t] = (np.log(y[t]) - np.log(y[T - 101])) * 100

        z_p = z_p[T - 101:T - 60]
        k_p = k_p[T - 101:T - 60]
        B_p = B_p[T - 101:T - 60]
        invest_p = invest_p[T - 101:T - 60]
        y_p = y_p[T - 101:T - 60]
        z = z[T - 101:T - 60]
        k = k[T - 101:T - 60]
        B = B[T - 101:T - 60]
        invest = invest[T - 101:T - 60]
        y = y[T - 101:T - 60]
        f = f[T - 101:T - 60]
        qs = qs[T - 101:T - 60]
        ql = ql[T - 101:T - 60]
        default = default[T - 101:T - 60]
        r_common_indices = r_common_indices[T - 101:T - 60]
        r_common = r_common[T - 101:T - 60]

        utils.save_data(r_common.tolist(), 'res_r')
        utils.save_data(z.tolist(), 'res_z')
        utils.save_data(k.tolist(), 'res_k')
        utils.save_data(B.tolist(), 'res_B')
        utils.save_data(invest.tolist(), 'res_i')
        utils.save_data(y.tolist(), 'res_y')
        utils.save_data(f.tolist(), 'res_f')
        utils.save_data(qs.tolist(), 'res_qs')
        utils.save_data(ql.tolist(), 'res_ql')
        utils.save_data(default.tolist(), 'res_default')
        utils.save_data(z_p.tolist(), 'res_z_p')
        utils.save_data(k_p.tolist(), 'res_k_p')
        utils.save_data(B_p.tolist(), 'res_B_p')
        utils.save_data(invest_p.tolist(), 'res_i_p')
        utils.save_data(y_p.tolist(), 'res_y_p')


        print('Done.')


    def simulate_shockr(self, r_common_indices, T, z_init=None, k_init=None, B_init=None, f_init=None):

        zero_B_index = np.searchsorted(self.Bgrid, 0)

        if z_init is None:
            z_init = np.searchsorted(self.zgrid, self.zgrid.mean())
        if k_init is None:
            k_init = np.searchsorted(self.kgrid, self.kgrid.mean())
        if B_init is None:
            B_init = zero_B_index
        if f_init is None:
            f_init = np.searchsorted(self.fgrid, self.fgrid.mean())

        mc_z = qe.markov.tauchen(self.rho_z, self.eta_z, m=3, n=self.nz)
        z_sim_indices = mc_z.simulate_indices(T, init=z_init)
        z_init_val = self.zgrid[z_sim_indices[T - 101]]
        z_init_val = z_init_val * 1.04
        z_init = find_nearest(self.zgrid, z_init_val)
        z_sim_indices[T - 100:T] = mc_z.simulate_indices(T - (T - 100), init=z_init)

        k_sim_indices = np.zeros(T, dtype=np.int32)
        k_sim_indices[0] = k_init
        B_sim_indices = np.zeros(T, dtype=np.int32)
        B_sim_indices[0] = B_init
        f_sim_indices = np.zeros(T, dtype=np.int32)
        f_sim_indices[0] = f_init
        qs_sim = np.ones(T)
        ql_sim = np.ones(T)
        invest = np.ones(T)
        y_sim = np.ones(T)
        in_default_series = np.zeros(T, dtype=np.int32)

        for t in range(T - 1):
            zi, ki, ri, Bi, fi = z_sim_indices[t], k_sim_indices[t], r_common_indices[t], B_sim_indices[t], f_sim_indices[t]
            if self.Vc[zi, ki, ri, Bi, fi] < self.Vd[zi, ki, ri]:
                in_default_series[t] = 1
                Bi_next = zero_B_index
                fi_next = 0
                ki_next = 0
            else:
                in_default_series[t] = 0
                newB_index = self.next_B_index[zi, ki, ri, Bi, fi]
                Bi_next = newB_index
                newf_index = self.next_f_index[zi, ki, ri, Bi, fi]
                fi_next = newf_index
                ki_next = self.next_k_index[zi, ki, ri, Bi, fi]
                if random.uniform(0, 1) < self.epsilon:
                    Bi_next = zero_B_index
                    fi_next = 0
                    ki_next = 0

            B_sim_indices[t + 1] = Bi_next
            f_sim_indices[t + 1] = fi_next
            k_sim_indices[t + 1] = ki_next
            invest[t] = self.kgrid[ki_next] - (1 - self.delta) * self.kgrid[ki] + self.theta_k / 2 * (
                    self.kgrid[ki_next] / self.kgrid[ki] - 1) ** 2 * self.kgrid[ki]
            qs_sim[t] = self.qs[zi, ki_next, ri, Bi_next, fi_next]
            ql_sim[t] = self.ql[zi, ki_next, ri, Bi_next, fi_next]
            y_sim[t] = self.zgrid[zi] * (self.kgrid[ki] ** self.alpha)

        B_sim_indices[-1] = B_sim_indices[-2]
        f_sim_indices[-1] = f_sim_indices[-2]
        k_sim_indices[-1] = k_sim_indices[-2]
        qs_sim[-1] = qs_sim[-2]
        ql_sim[-1] = ql_sim[-2]
        invest[-1] = invest[-2]
        y_sim[-1] = y_sim[-2]

        return_vecs = (self.zgrid[z_sim_indices],
                       self.kgrid[k_sim_indices],
                       self.Bgrid[B_sim_indices],
                       self.fgrid[f_sim_indices],
                       qs_sim,
                       ql_sim,
                       invest,
                       y_sim,
                       in_default_series)
        return return_vecs

def find_nearest(grid, value):
    idx = np.searchsorted(grid, value)
    if idx >= len(grid):
        return len(grid)-1
    return idx


if __name__ == "__main__":
    ie = Simulation()
    print('Done')
