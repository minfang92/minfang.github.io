
import matplotlib
import numpy as np
import matplotlib.pyplot as plt
import utils
from matplotlib.ticker import MaxNLocator

# matplotlib.rcParams.update({'font.size': 14})

res_r = utils.check_load_data('res_r')
res_r = np.asarray(res_r)
res_qs = utils.check_load_data('res_qs')
res_qs = np.asarray(res_qs)
res_ql = utils.check_load_data('res_ql')
res_ql = np.asarray(res_ql)
res_B_p = utils.check_load_data('res_B_p')
res_B_p = np.asarray(res_B_p)
res_i = utils.check_load_data('res_i')
res_i = np.asarray(res_i)
res_k = utils.check_load_data('res_k')
res_k = np.asarray(res_k)
res_k_p = utils.check_load_data('res_k_p')
res_k_p = np.asarray(res_k_p)
res_y_p = utils.check_load_data('res_y_p')
res_y_p = np.asarray(res_y_p)
res_f = utils.check_load_data('res_f')
res_f = np.asarray(res_f)

T = 41
plt.figure(figsize=(6,4.5))
plt.plot(range(T), res_r*10000, linestyle = '-',color='b', lw=2, alpha=0.7)
plt.ylabel('bps')
plt.xlim([0,16])
plt.savefig('1_res_r.pdf')


plt.figure(figsize=(6,4.5))
plt.plot(range(T), (res_i/res_k  - res_i[0]/res_k[0]) * 100, linestyle = '-', color='b', lw=2, alpha=0.7)
plt.ylabel('%')
plt.xlim([0,16])
plt.savefig('2_res_investmentrate.pdf')

print("Done")

