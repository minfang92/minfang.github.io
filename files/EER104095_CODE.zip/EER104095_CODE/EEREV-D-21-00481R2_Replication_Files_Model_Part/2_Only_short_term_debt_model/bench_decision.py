"""

Reference model: only-short-term-debt model

"""

from __future__ import division
import numpy as np
import quantecon as qe
import matplotlib.pyplot as plt
from numba import jit, prange
import utils
import time
import sys

st_time = time.time()


class Maturity_Economy:
    def __init__(self,
                 beta = 0.92,
                 alpha = 0.65,  # capital share in production function
                 delta = 0.025,  # depreciation of capital
                 lambd = 0.05,  # fraction of repayment for long-term bond
                 tau = 0.2,  # corporate income tax rate
                 epsilon = 0.005,  # exogenous death rate
                 theta_k = 0.2,  # capital adjustment cost parameter
                 theta_bs = 1,  # short term bond issuance cost
                 theta_bl = 3,  # long-term bond issuance cost
                 chi = 0.8,  # recovery rate
                 mul = 1.0,  # weight for long-term debt
                 phi = 0.8,  # fixed cost of operating
                 rbar = 0.01,  # to scale interest rate
                 rho_r = 0.5,  # persistence in interest rate
                 eta_r = 0.08,  # st dev of interest rate
                 rho_z = 0.86,  # persistence in productivity
                 eta_z = 0.03,  # st dev of productivity
                 nz = 11,  # number of points in z grid
                 nr = 11,  # number of points in r grid
                 nk = 30,  # number of points in k grid
                 nB = 30,  # number of points in Bgrid (total debt)
                 nf = 10,  # number of points in fgrud (fraction of long-term debt)
                 tol = 5e-5,  # error tolerance in iteration
                 maxit = 1500):

        # Save parameters
        self.beta, self.alpha, self.delta = beta, alpha, delta
        self.lambd, self.tau, self.epsilon = lambd, tau, epsilon
        self.theta_k, self.theta_bs, self.theta_bl = theta_k, theta_bs, theta_bl
        self.chi, self.mul, self.phi = chi, mul, phi
        self.rbar, self.rho_r, self.eta_r = rbar, rho_r, eta_r
        self.rho_z, self.eta_z, = rho_z, eta_z
        self.nz, self.nr, self.nk, self.nB, self.nf = nz, nr, nk, nB, nf

        file = open("Paramaters_AND_Simulated_Moments_c.txt", 'w')
        file.write(str(theta_k) + "\n")
        file.write(str(theta_bs) + "\n")
        file.write(str(theta_bl) + "\n")
        file.write(str(phi) + "\n")
        file.write(" " + "\n")
        file.close()

        # Create grids and discretize Markov process
        self.mc_z = qe.markov.tauchen(rho_z, eta_z, m=3, n=nz)
        self.zgrid = np.exp(self.mc_z.state_values)
        self.Pz = self.mc_z.P

        self.mc_r = qe.markov.tauchen(rho_r, eta_r, m=3, n=nr)
        self.rgrid = np.exp(self.mc_r.state_values)
        self.Pr = self.mc_r.P
        self.rgrid = self.rbar * self.rgrid


        self.kgrid = np.linspace(0.5, 4.5, nk)
        self.Bgrid = np.linspace(0, 2, nB)
        self.fgrid = np.array([0])

        # Allocate memory
        self.Vd = np.zeros((nz, nk, nr))
        self.Vc = np.zeros((nz, nk, nr, nB, nf))
        self.V = np.zeros((nz, nk, nr, nB, nf))
        self.Qs = np.ones((nz, nk, nr, nB, nf)) * .96
        self.Ql = np.ones((nz, nk, nr, nB, nf)) * .96
        self.default_prob = np.zeros((nz, nk, nr, nB, nf))

        self.next_B_index = np.zeros((nz, nk, nr, nB, nf), dtype=np.int32)
        self.next_f_index = np.zeros((nz, nk, nr, nB, nf), dtype=np.int32)
        self.next_k_index = np.zeros((nz, nk, nr, nB, nf), dtype=np.int32)

        self.points = _Ndim(self.zgrid, self.kgrid, self.rgrid, self.Bgrid, self.fgrid)

        # Compute the value functions, prices, and default prob
        self.solve(tol=tol, maxit=maxit)
        print('Value function iteration converged.')

        print(np.min(self.Vc))
        print(np.max(self.Vc))

        utils.save_data(self.default_prob.tolist(), 'defprob')
        utils.save_data(self.next_B_index.tolist(), 'nextB')
        utils.save_data(self.next_f_index.tolist(), 'nextf')
        utils.save_data(self.next_k_index.tolist(), 'nextk')

        utils.save_data(self.Vd.tolist(), 'Vd')
        utils.save_data(self.Vc.tolist(), 'Vc')
        utils.save_data(self.Qs.tolist(), 'qs')
        utils.save_data(self.Ql.tolist(), 'ql')

        utils.save_data(self.zgrid.tolist(), 'zgrid')
        utils.save_data(self.kgrid.tolist(), 'kgrid')
        utils.save_data(self.Bgrid.tolist(), 'Bgrid')
        utils.save_data(self.fgrid.tolist(), 'fgrid')
        utils.save_data(self.rgrid.tolist(), 'rgrid')

        print("Decision rules saved!")

        ed_time = time.time()
        print("Running time:")
        print(ed_time - st_time)


    def solve(self, tol, maxit):
        it = 0
        dist_v = 10.
        dist_g = 10.
        V_upd = np.zeros((self.nz, self.nk, self.nr, self.nB, self.nf))
        Ql_upd = np.ones((self.nz, self.nk, self.nr, self.nB, self.nf)) * 0.96

        while (dist_v > tol or dist_g > tol) and maxit > it:

            Vs = self.V, self.Vd, self.Vc
            self.EV, self.EVd, self.EVc = (np.swapaxes(np.swapaxes(np.tensordot(self.Pr, np.tensordot(self.Pz, v, axes=([1], [0])),
                                                                                axes=([1], [2])), 0, 2), 0, 1) for v in Vs)


            _valuefun(self.points, self.zgrid, self.kgrid, self.rgrid, self.Bgrid, self.fgrid, self.Vd, self.Vc,
                        self.EV, self.Qs, self.Ql,
                        self.delta, self.alpha, self.theta_k, self.lambd, self.tau, self.theta_bs,self.theta_bl,
                        self.epsilon, self.beta, self.next_B_index, self.next_f_index, self.next_k_index, self.phi, self.rbar)

            Vd_compat = np.expand_dims(self.Vd, axis=3)
            Vd_compat = np.expand_dims(Vd_compat, axis=4)
            Vd_compat = np.tile(Vd_compat, (1, 1, 1, self.nB, self.nf))
            self.default_states = Vd_compat > self.Vc
            self.default_prob = (np.swapaxes(np.swapaxes(np.tensordot(self.Pr,np.tensordot(self.Pz, self.default_states,
                                                                                   axes=([1], [0])), axes=([1], [2])), 0, 2), 0, 1))


            V_upd[:, :, :, :, :] = np.maximum(self.Vc, Vd_compat)
            dist_v = euclidean_dist(V_upd, self.V)
            self.V[:, :, :, :, :] = V_upd[:, :, :, :, :]

            _bondprice(self.points, self.Qs, self.Ql, Ql_upd, self.lambd, self.default_prob, self.rgrid, self.mul, self.chi, self.tau, self.zgrid, self.kgrid,
                       self.Bgrid, self.fgrid, self.alpha, self.delta, self.theta_k, self.epsilon)

            dist_g = euclidean_dist(Ql_upd, self.Ql)
            Ql_upd[:, :, :, :, :] = self.Ql[:, :, :, :, :]

            it += 1
            if it % 5 == 0:
                print("Value function: Running iteration {} with dist_v of {}".format(it, dist_v))
                print("Value function: Running iteration {} with dist_g of {}".format(it, dist_g))
                sys.stdout.flush()


@jit(nopython=True, parallel=True)
def _valuefun(points, zgrid, kgrid, rgrid, Bgrid, fgrid, Vd, Vc, EV, qqs, qql, delta, alpha, theta_k, lambd, tau,
                theta_bs, theta_bl, epsilon, beta, next_B_index, next_f_index, next_k_index, phi, rbar):

    nz, nk, nr, nB, nf = len(zgrid), len(kgrid), len(rgrid), len(Bgrid), len(fgrid)
    for x in prange(points.shape[0]):
        iz = points[x, 0]
        ik = points[x, 1]
        ir = points[x, 2]
        ib = points[x, 3]
        i_f = points[x, 4]

        z = zgrid[iz]
        k = kgrid[ik]
        r = rgrid[ir]
        B = Bgrid[ib]
        f = fgrid[i_f]

        Vd[iz, ik, ir] = 0
        current_max = -1e14
        current_max_indexb = 0
        current_max_indexf = 0
        current_max_indexk = 0
        for ik_next in range(nk):
            for ib_next in range(nB):
                for if_next in range(nf):
                    d = (1 - tau) * (z * (k ** alpha) - delta * k) - (B * (1 - f) + lambd * B * f) - (kgrid[ik_next] - k) \
                        - theta_k / 2 * (kgrid[ik_next] / k - 1) ** 2 * k \
                        + qqs[iz, ik_next, ir, ib_next, if_next] * Bgrid[ib_next] * (1 - fgrid[if_next]) \
                        - theta_bs * (Bgrid[ib_next] * (1 - fgrid[if_next])) ** 2

                    if d >= 0:
                        sdf = (1 + rbar) / (1 + r)
                        m = d - phi + (1 - epsilon) * beta * sdf * EV[iz, ik_next, ir, ib_next, if_next]
                        if m > current_max:
                            current_max = m
                            current_max_indexb = ib_next
                            current_max_indexf = if_next
                            current_max_indexk = ik_next
        Vc[iz, ik, ir, ib, i_f] = current_max
        next_B_index[iz, ik, ir, ib, i_f] = current_max_indexb
        next_f_index[iz, ik, ir, ib, i_f] = current_max_indexf
        next_k_index[iz, ik, ir, ib, i_f] = current_max_indexk



@jit(nopython=True, parallel=True)
def _bondprice(points, Qs, Ql, Ql_upd,lambd, default_prob, rgrid, mul, chi, tau, zgrid, kgrid, Bgrid, fgrid, alpha, delta, theta_k, epsilon):

    for x in prange(points.shape[0]):
        iz = points[x, 0]
        ik = points[x, 1]
        ir = points[x, 2]
        ib = points[x, 3]
        i_f = points[x, 4]

        z = zgrid[iz]
        k = kgrid[ik]
        r = rgrid[ir]
        B = Bgrid[ib]
        f = fgrid[i_f]

        R = max(chi * ((1 - tau) * (z * k ** alpha - delta * k) + k - theta_k / 2 * k), 0)
        # share of recovery value for short-term debt
        s = (1-f) / (1 - f + mul * f)
        # have both short and long debt
        if B > 0 and f > 0 and f < 1:
            Qs[iz, ik, ir, ib, i_f] = (1 - default_prob[iz, ik, ir, ib, i_f]
                                        + default_prob[iz, ik, ir, ib, i_f] * s * R / (B*(1-f))) * (1-epsilon)/ (1 + r)

            Ql[iz, ik, ir, ib, i_f] = ((1 - default_prob[iz, ik, ir, ib, i_f]) * (
                                        lambd + (1 - lambd) * Ql_upd[iz, ik, ir, ib, i_f]) +
                                        default_prob[iz, ik, ir, ib, i_f] * (1 - s) * R / (B * f)) * (1-epsilon)/ (1 + r)
        # only have short debt
        if B > 0 and f == 0:
            Qs[iz, ik, ir, ib, i_f] = (1 - default_prob[iz, ik, ir, ib, i_f]
                                        + default_prob[iz, ik, ir, ib, i_f] * s * R / (B*(1-f))) * (1-epsilon)/ (1 + r)

            Ql[iz, ik, ir, ib, i_f] = ((1 - default_prob[iz, ik, ir, ib, i_f]) * (
                                        lambd + (1 - lambd) * Ql_upd[iz, ik, ir, ib, i_f])) * (1-epsilon)/ (1 + r)
        # only have long debt
        if B > 0 and f == 1:
            Qs[iz, ik, ir, ib, i_f] = (1 - default_prob[iz, ik, ir, ib, i_f]) * (1-epsilon)/ (1 + r)

            Ql[iz, ik, ir, ib, i_f] = ((1 - default_prob[iz, ik, ir, ib, i_f]) * (
                                        lambd + (1 - lambd) * Ql_upd[iz, ik, ir, ib, i_f]) +
                                        default_prob[iz, ik, ir, ib, i_f] * (1 - s) * R / (B * f)) * (1-epsilon)/ (1 + r)
        else:
            Qs[iz, ik, ir, ib, i_f] = (1 - default_prob[iz, ik, ir, ib, i_f]) * (1-epsilon)/ (1 + r)

            Ql[iz, ik, ir, ib, i_f] = ((1 - default_prob[iz, ik, ir, ib, i_f]) * (
                                        lambd + (1 - lambd) * Ql_upd[iz, ik, ir, ib, i_f])) * (1-epsilon)/ (1 + r)


@jit(nopython=True, parallel=True)
def _Ndim(zgrid, kgrid, rgrid, Bgrid, fgrid):

    nz, nk, nr, nB, nf = len(zgrid), len(kgrid), len(rgrid), len(Bgrid), len(fgrid)

    points = -1 * np.ones((nz, nk, nr, nB, nf, 5), dtype=np.int32)
    for iz in prange(nz):
        points[iz, :, :, :, :, 0] = iz
    for ik in prange(nk):
        points[:, ik, :, :, :, 1] = ik
    for ir in prange(nr):
        points[:, :, ir, :, :, 2] = ir
    for ib in prange(nB):
        points[:, :, :, ib, :, 3] = ib
    for i_f in prange(nf):
        points[:, :, :, :, i_f, 4] = i_f

    points = points.reshape((-1, 5))

    return points


@jit(nopython=True, parallel=True)
def _print_for_defaultstates(zgrid, kgrid, rgrid, Bgrid, fgrid,points,default_states):

    nz, nk, nr, nB, nf = len(zgrid), len(kgrid), len(rgrid), len(Bgrid), len(fgrid)
    for x in prange(points.shape[0]):
        iz = points[x, 0]
        ik = points[x, 1]
        ir = points[x, 2]
        ib = points[x, 3]
        i_f = points[x, 4]
        if default_states[iz, ik, ir, ib, i_f] == 1:
            print(iz, ik, ir, ib, i_f)



@jit(nopython=True)
def euclidean_dist(A, B):
    numerator = np.sqrt(np.sum((A - B) ** 2))
    denominator = 1 + np.sqrt(np.sum(A ** 2))
    dist = numerator / denominator
    return dist


if __name__ == "__main__":
    me = Maturity_Economy()
    print('Done')
