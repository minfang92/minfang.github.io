#This File include several functions to help reduce solving time
